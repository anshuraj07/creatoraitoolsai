export interface Tool {
  id: string;
  name: string;
  description: string;
  category: 'Video editing' | 'Caption generator' | 'Thumbnail maker' | 'Script generator' | 'AI Automation Tools';
  rating: number;
  image: string;
  affiliateLink: string;
  price: string;
  features: string[];
  pros: string[];
  cons: string[];
  isTrending?: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  date: string;
  category: string;
  image: string;
  author: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
}
