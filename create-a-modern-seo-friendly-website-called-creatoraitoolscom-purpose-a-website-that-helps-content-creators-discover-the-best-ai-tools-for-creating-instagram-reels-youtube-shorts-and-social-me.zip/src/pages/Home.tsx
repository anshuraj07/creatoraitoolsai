import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, TrendingUp, Mail } from 'lucide-react';
import { tools, blogPosts } from '../data/mockData';

const Home = () => {
  const featuredTools = tools.slice(0, 3);
  const topTools = tools.filter(t => t.isTrending).slice(0, 3);
  const latestBlogs = blogPosts.slice(0, 3);

  return (
    <div className="animate-in fade-in duration-500">
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent -z-10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight mb-6">
            Discover the Best <br />
            <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-purple-400 bg-clip-text text-transparent animate-gradient">
              AI Tools for Creators
            </span>
          </h1>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-10">
            Boost your content creation with powerful AI tools for video editing, captions, thumbnails, and automation.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link 
              to="/directory" 
              className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all hover:scale-105 flex items-center justify-center gap-2"
            >
              Explore Tools <ArrowRight size={20} />
            </Link>
            <Link 
              to="/blog" 
              className="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all"
            >
              Read Guides
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Tools Section */}
      <section className="py-20 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured AI Tools</h2>
              <p className="text-slate-400">Handpicked tools to elevate your content.</p>
            </div>
            <Link to="/directory" className="text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1">
              View All <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredTools.map((tool) => (
              <div key={tool.id} className="group bg-slate-800/50 border border-slate-700 rounded-2xl overflow-hidden hover:border-purple-500/50 transition-all hover:-translate-y-2">
                <img src={tool.image} alt={tool.name} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold">{tool.name}</h3>
                    <div className="flex items-center text-yellow-400 text-sm">
                      <Star size={14} fill="currentColor" className="mr-1" />
                      {tool.rating}
                    </div>
                  </div>
                  <p className="text-slate-400 text-sm mb-4 line-clamp-2">{tool.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium px-2 py-1 bg-slate-700 rounded-md text-slate-300">{tool.category}</span>
                    <Link to={`/tool/${tool.id}`} className="text-purple-400 text-sm font-bold hover:text-purple-300">View Tool</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-sm font-medium mb-4">
              <TrendingUp size={16} /> Trending Now
            </div>
            <h2 className="text-4xl font-bold">Top Tools for Reels & Shorts</h2>
            <p className="text-slate-400 mt-4">The fastest-growing tools used by top influencers.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {topTools.map((tool) => (
              <div key={tool.id} className="flex items-center p-6 bg-slate-900 border border-slate-800 rounded-2xl gap-4">
                <img src={tool.image} alt={tool.name} className="w-16 h-16 rounded-lg object-cover" />
                <div className="flex-grow">
                  <h3 className="font-bold">{tool.name}</h3>
                  <p className="text-xs text-slate-500">{tool.category}</p>
                </div>
                <Link to={`/tool/${tool.id}`} className="text-sm text-purple-400 font-medium">Details</Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Blog Section */}
      <section className="py-20 bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl font-bold mb-2">Latest AI Insights</h2>
              <p className="text-slate-400">Stay ahead with our expert guides and reviews.</p>
            </div>
            <Link to="/blog" className="text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1">
              Read Blog <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {latestBlogs.map((post) => (
              <article key={post.id} className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-2xl mb-4 aspect-video">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-purple-600/80 backdrop-blur-sm text-white text-xs font-bold rounded-full">
                      {post.category}
                    </span>
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2 group-hover:text-purple-400 transition-colors">{post.title}</h3>
                <p className="text-slate-400 text-sm mb-4 line-clamp-2">{post.excerpt}</p>
                <div className="text-xs text-slate-500 flex items-center gap-2">
                  <span>{post.date}</span>
                  <span>•</span>
                  <span>{post.author}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 border border-purple-500/30 rounded-3xl p-8 md:p-16 text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none" />
            <Mail className="mx-auto text-purple-400 mb-6" size={48} />
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Join the Creator Revolution</h2>
            <p className="text-slate-300 mb-10 max-w-xl mx-auto">
              Get weekly curated lists of the best AI tools, tutorials, and industry news delivered to your inbox.
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input 
                type="email" 
                placeholder="you@example.com" 
                className="flex-grow bg-slate-950/50 border border-slate-700 rounded-xl px-6 py-4 text-white focus:outline-none focus:border-purple-500"
              />
              <button className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 rounded-xl font-bold transition-all">
                Subscribe
              </button>
            </form>
            <p className="text-xs text-slate-500 mt-6">No spam, just pure AI value. Unsubscribe anytime.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
