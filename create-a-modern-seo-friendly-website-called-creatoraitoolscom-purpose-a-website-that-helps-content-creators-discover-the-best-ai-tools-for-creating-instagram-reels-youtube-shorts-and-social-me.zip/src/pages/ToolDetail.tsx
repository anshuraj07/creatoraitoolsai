import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Star, CheckCircle2, XCircle, ExternalLink, Package, Zap, ShieldCheck } from 'lucide-react';
import { tools } from '../data/mockData';

const ToolDetail = () => {
  const { id } = useParams();
  const tool = tools.find(t => t.id === id);

  if (!tool) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Tool not found</h1>
          <Link to="/directory" className="text-purple-400 hover:underline">Back to Directory</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back button */}
        <Link 
          to="/directory" 
          className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft size={20} /> Back to Directory
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="mb-8">
              <span className="px-3 py-1 bg-purple-500/10 text-purple-400 text-sm font-bold rounded-full">
                {tool.category}
              </span>
              <h1 className="text-4xl md:text-5xl font-extrabold mt-4 mb-6">{tool.name}</h1>
              <p className="text-xl text-slate-400 leading-relaxed">{tool.description}</p>
            </div>

            <div className="aspect-video rounded-3xl overflow-hidden bg-slate-900 mb-12 border border-slate-800">
               <img src={tool.image} alt={tool.name} className="w-full h-full object-cover opacity-80" />
               <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                  <p className="text-slate-400 italic">Screenshot Placeholder</p>
               </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl">
                <div className="flex items-center gap-2 text-green-400 font-bold mb-4">
                  <CheckCircle2 size={20} /> Pros
                </div>
                <ul className="space-y-3">
                  {tool.pros.map((pro, i) => (
                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                      <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-green-500 shrink-0" />
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl">
                <div className="flex items-center gap-2 text-red-400 font-bold mb-4">
                  <XCircle size={20} /> Cons
                </div>
                <ul className="space-y-3">
                  {tool.cons.map((con, i) => (
                    <li key={i} className="text-slate-300 text-sm flex items-start gap-2">
                      <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-red-500 shrink-0" />
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-6">Key Features</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {tool.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-3 p-4 bg-slate-900/50 border border-slate-800 rounded-xl">
                    <Zap size={18} className="text-purple-400" />
                    <span className="text-slate-300">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8">
                <h3 className="text-xl font-bold mb-6">Get Started</h3>
                
                <div className="space-y-6 mb-8">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Package size={18} />
                      <span>Pricing</span>
                    </div>
                    <span className="font-bold">{tool.price}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Star size={18} />
                      <span>Rating</span>
                    </div>
                    <div className="flex items-center text-yellow-400">
                      <Star size={16} fill="currentColor" className="mr-1" />
                      {tool.rating}
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2 text-slate-400">
                      <ShieldCheck size={18} />
                      <span>Category</span>
                    </div>
                    <span className="text-sm font-medium">{tool.category}</span>
                  </div>
                </div>

                <a 
                  href={tool.affiliateLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all group"
                >
                  Try This Tool <ExternalLink size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                </a>
                
                <p className="text-center text-xs text-slate-500 mt-4">
                  * We may earn a commission from purchases made through this link.
                </p>
              </div>

              <div className="bg-gradient-to-br from-blue-600/20 to-purple-600/20 border border-blue-500/30 rounded-3xl p-8">
                <h3 className="text-lg font-bold mb-2">Looking for more?</h3>
                <p className="text-sm text-slate-400 mb-6">Explore all our top-rated tools in the directory.</p>
                <Link to="/directory" className="inline-block text-sm font-bold text-blue-400 hover:text-blue-300">
                  Browse Directory →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ToolDetail;
