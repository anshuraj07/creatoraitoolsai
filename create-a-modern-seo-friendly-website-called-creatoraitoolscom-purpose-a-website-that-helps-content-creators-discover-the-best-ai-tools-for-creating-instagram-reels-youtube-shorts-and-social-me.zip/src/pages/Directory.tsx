import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Star, LayoutGrid, List } from 'lucide-react';
import { tools, categories } from '../data/mockData';

const Directory = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredTools = useMemo(() => {
    return tools.filter(tool => {
      const matchesSearch = tool.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          tool.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory ? tool.category === selectedCategory : true;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  return (
    <div className="py-12 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-12 text-center md:text-left">
          <h1 className="text-4xl font-bold mb-4">AI Tools Directory</h1>
          <p className="text-slate-400">Explore the most powerful AI tools for your content creation workflow.</p>
        </div>

        {/* Filters & Search */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 items-center justify-between">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
            <input 
              type="text"
              placeholder="Search tools..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:border-purple-500 transition-colors"
            />
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 w-full md:w-auto">
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1">
              <Filter size={16} className="text-slate-500" />
              <select 
                className="bg-transparent focus:outline-none text-sm py-2 pr-8"
                value={selectedCategory || ''}
                onChange={(e) => setSelectedCategory(e.target.value || null)}
              >
                <option value="">All Categories</option>
                <option value="Video editing">Video editing</option>
                <option value="Caption generator">Caption generator</option>
                <option value="Thumbnail maker">Thumbnail maker</option>
                <option value="Script generator">Script generator</option>
                <option value="AI Automation Tools">AI Automation Tools</option>
              </select>
            </div>

            <div className="flex bg-slate-900 border border-slate-800 rounded-xl p-1">
              <button 
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:text-slate-300'}`}
              >
                <LayoutGrid size={20} />
              </button>
              <button 
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:text-slate-300'}`}
              >
                <List size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6 text-sm text-slate-500">
          Showing {filteredTools.length} {filteredTools.length === 1 ? 'tool' : 'tools'}
        </div>

        {/* Tools List/Grid */}
        {filteredTools.length > 0 ? (
          <div className={viewMode === 'grid' 
            ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" 
            : "flex flex-col gap-4"
          }>
            {filteredTools.map((tool) => (
              <div 
                key={tool.id} 
                className={`group bg-slate-900 border border-slate-800 hover:border-purple-500/50 transition-all overflow-hidden ${
                  viewMode === 'grid' ? 'rounded-2xl' : 'rounded-xl flex flex-col sm:flex-row items-center'
                }`}
              >
                <div className={`${viewMode === 'grid' ? 'w-full h-48' : 'w-full sm:w-48 h-48'} relative overflow-hidden`}>
                  <img 
                    src={tool.image} 
                    alt={tool.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                  />
                </div>
                
                <div className="p-6 flex-grow">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold">{tool.name}</h3>
                    <div className="flex items-center text-yellow-400 text-sm">
                      <Star size={14} fill="currentColor" className="mr-1" />
                      {tool.rating}
                    </div>
                  </div>
                  <p className="text-slate-400 text-sm mb-4 line-clamp-2">{tool.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-1 bg-slate-800 rounded text-slate-400">
                      {tool.category}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider font-bold px-2 py-1 bg-purple-500/10 rounded text-purple-400">
                      {tool.price}
                    </span>
                  </div>

                  <Link 
                    to={`/tool/${tool.id}`}
                    className={`w-full inline-flex items-center justify-center bg-slate-800 hover:bg-purple-600 text-white py-2 rounded-lg transition-colors text-sm font-bold ${
                      viewMode === 'list' ? 'sm:w-auto sm:px-6' : ''
                    }`}
                  >
                    View Tool
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="text-slate-600 mb-4">
              <Search size={48} className="mx-auto" />
            </div>
            <h3 className="text-xl font-bold text-slate-300">No tools found</h3>
            <p className="text-slate-500">Try adjusting your search or filters.</p>
            <button 
              onClick={() => {setSearchQuery(''); setSelectedCategory(null);}}
              className="mt-4 text-purple-400 hover:text-purple-300 text-sm font-medium"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Directory;
