import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { tools, categories } from '../data/mockData';

const CategoryPage = () => {
  const { categorySlug } = useParams();
  
  const category = categories.find(c => c.slug === categorySlug);
  
  if (!category) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Category not found</h1>
          <Link to="/directory" className="text-purple-400 hover:underline">Back to Directory</Link>
        </div>
      </div>
    );
  }

  const filteredTools = tools.filter(tool => tool.category === category.name);

  return (
    <div className="py-12 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <div className="flex items-center gap-4 mb-4">
             <span className="text-4xl">{category.icon}</span>
             <h1 className="text-4xl font-bold">{category.name}</h1>
          </div>
          <p className="text-slate-400">Discover the best AI-powered tools specifically for {category.name.toLowerCase()}.</p>
        </div>

        {filteredTools.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTools.map((tool) => (
              <div key={tool.id} className="group bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden hover:border-purple-500/50 transition-all">
                <div className="relative h-48 overflow-hidden">
                  <img src={tool.image} alt={tool.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold">{tool.name}</h3>
                    <div className="flex items-center text-yellow-400 text-sm">
                      <span className="mr-1">★</span>
                      {tool.rating}
                    </div>
                  </div>
                  <p className="text-slate-400 text-sm mb-4 line-clamp-2">{tool.description}</p>
                  <Link 
                    to={`/tool/${tool.id}`} 
                    className="inline-block w-full text-center bg-slate-800 hover:bg-purple-600 text-white py-2 rounded-lg transition-colors text-sm font-bold"
                  >
                    View Tool
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-slate-500 text-lg">No tools found in this category yet.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryPage;
