import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Directory from './pages/Directory';
import Blog from './pages/Blog';
import ToolDetail from './pages/ToolDetail';
import CategoryPage from './pages/CategoryPage';
import './index.css';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="directory" element={<Directory />} />
          <Route path="blog" element={<Blog />} />
          <Route path="categories/:categorySlug" element={<CategoryPage />} />
          <Route path="tool/:id" element={<ToolDetail />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
