import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="text-xl font-bold bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">
              CreatorAI
            </Link>
            <p className="mt-4 text-sm">
              Discover the best AI tools to supercharge your content creation process.
            </p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/directory" className="hover:text-purple-400">AI Tools Directory</Link></li>
              <li><Link to="/blog" className="hover:text-purple-400">Blog</Link></li>
              <li><Link to="/categories" className="hover:text-purple-400">Categories</Link></li>
              <li><Link to="/submit" className="hover:text-purple-400">Submit a Tool</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Categories</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/categories/ai-video-tools" className="hover:text-purple-400">Video Tools</Link></li>
              <li><Link to="/categories/ai-caption-generators" className="hover:text-purple-400">Caption Generators</Link></li>
              <li><Link to="/categories/ai-script-writers" className="hover:text-purple-400">Script Writers</Link></li>
              <li><Link to="/categories/ai-thumbnail-generators" className="hover:text-purple-400">Thumbnail Generators</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4">Newsletter</h3>
            <p className="text-sm mb-4">Get the latest AI tool updates directly in your inbox.</p>
            <form className="flex flex-col space-y-2">
              <input 
                type="email" 
                placeholder="Enter your email" 
                className="bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-purple-500"
              />
              <button className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                Subscribe
              </button>
            </form>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-slate-800 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} CreatorAITools.com. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
